t = int(input())
a=0
b=7
for i in range(t):
    n=int(input())
    
    d1=abs(n-a)
    d2=abs(n-b)

    if d1<d2:
        print('A')
        a=n
    elif d1>d2:
        print('B')
        b=n
    else:
        print('A')
        a=n
