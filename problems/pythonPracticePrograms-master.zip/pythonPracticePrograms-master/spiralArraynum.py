########################################################################
#print below
#1 8 7 
#2 9 6
#3 4 5
########################################################################
import array
a=[[None,None,None],[None,None,None],[None,None,None]]

max=3
min=1
i=1
j=1
k=1
midstart='N'
while(k<10):
    #print(a)
    #print(k,i,j)
    if i<max and j!=max:
        a[i-1][j-1]=k
        #print('asaving %i at %i %i' %(k,i-1,j-1))
        i=i+1
        
    elif i==max and j<max:
        a[i-1][j-1]=k
        #print('bsaving %i at %i %i' %(k,i-1,j-1))
        j=j+1
        
    elif i<=max and i>=min and j==max  and midstart!='Y':
        a[i-1][j-1]=k
        #print('csaving %i at %i %i' %(k,i-1,j-1))
        if i>1:
            i=i-1
        else:
            midstart='Y'

    elif i>=min and j==max and midstart!='Y':
        a[i-1][j-1]=k
        #print('dsaving %i at %i %i' %(k,i-1,j-1))
        i=i+1
    elif midstart=='Y':
        if j==max:
            j=j-1
        a[i-1][j-1]=k
        #print('esaving %i at %i %i' %(k,i-1,j-1))
        i=i+1
    k=k+1

print(a[0])
print(a[1])
print(a[2])
