t= int(input())
for _ in t:
    a=[i for i in str(input())]
    b=[i for i in str(input())]
    c=len(a)+len(b)
    l=set(a).intersection(set(b))
    s=[]
    for i in l:
        k=min(a.count(i),b.count(i))
        for j in range(k):
            s.append(i)

    m1=len(a)-len(s)
    m2=len(b)-len(s)
    print(m1+m2)
