t = str(input())
n=[0,0]
for i in t:
    if i=='L':
        n[0]-=1
    elif i=='R':
        n[0]+= 1
    elif i=='U':
        n[1]+=1
    elif i=='D':
        n[1]-=1
print(n[0],n[1])
