import  math
t = int(input())
w=[]
for _ in range(t):
    w.append([int(i) for i in str(input()).split(' ')])

for d in w:
    t1=d[0]*60+d[1]
    t2=d[2]*60+d[3]
    d=abs(t2-t1)
    h=d/60
    m=d%60
    if h<0:
        h=0
    else:
        h=math.floor(h)
    print(h,m)
