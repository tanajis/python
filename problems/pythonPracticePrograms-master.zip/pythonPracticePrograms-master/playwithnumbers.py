import math
from sys import stdin, stdout
n,q=map(int,stdin.readline().split())
#print(n,q)

arr=[0]
for x in stdin.readline().split():
    arr.append(int(x)+arr[-1])

for k in stdin.readlines():
    l,r=map(int,k.split())
    n=r-l+1
    S=arr[r]-arr[l-1]
    res=str(S//n)
    print(res)
