n=int(input())
for i in range(2,n):
    flg=1
    j=2
    while(j<=n):
        if i%j==0 and i!=j:
            flg=0
            break
        j+=1
    if flg==1:
        print(i,end=" ")
