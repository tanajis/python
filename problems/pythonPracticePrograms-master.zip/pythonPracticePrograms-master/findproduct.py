import math
t=input()
a=[int(i) for i in str(input()).split(' ')]
k=1
for i in a:
    k=(k*i)%((math.pow(10,9)+7))
    #k = (k * i) % (1000000007)
print(round(k))

