instr=str(input())
s=0
for i in instr:
    s=s+ord(i)-96
print(s)
