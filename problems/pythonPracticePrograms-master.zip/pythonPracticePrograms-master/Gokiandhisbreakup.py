n=int(input())
minskill=int(input())
skilllist=[]
for i in range(n):
    skilllist.append(int(input()))

for i in skilllist:
    if i>=minskill:
        print('YES')
    else:
        print('NO')
