a=str(input())
#a="13X357-22"
arr=[i for i in a]
flg='valid'
for i in range(len(arr)):
    #print('check1',i)
    if i==2 or i==1:
        a = ["A", "E", "I", "O", "U", "Y"]
        if a.__contains__(arr[i]):
            flg = 'invalid'
            #print('check2')
            break
        else:
            #print('check3')
            continue
    elif i==6 or i==5 or i==8:
        #print('check4')
        continue
    else:
        s = int(arr[i]) + int(arr[i + 1])
        if s % 2 != 0 and s != 1:
            #print('check5')
            flg = 'invalid'
            break
        else:
            flg = 'valid'
print(flg)

