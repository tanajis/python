def isPrime(n):
    # This fuction returns true if given number is prim else false
    flg = 1
    j = 2
    for i in range(2,n):
        if n % i == 0 and n != i:
            flg=0
            break
    if flg==1:
        return True
    else:
        return False
 
 
def nearestprim(n):
    if isPrime(n) and (n<=122 and  n>=65):
        return n
    belownum=n
    abovenum=n
    nearestPrim=n
 
 
    while(1):
        if abovenum < 122:
            abovenum = abovenum + 1
            #print("abovenum", abovenum)
        if belownum > 65:
            belownum = belownum - 1
            #print("belownum", belownum)
        if isPrime(belownum) and belownum > 64 and belownum < 123:
            nearestPrim = belownum
            #print("nearestPrim", nearestPrim)
            break
        elif (isPrime(abovenum) and abovenum < 123 and abovenum > 64):
            nearestPrim = abovenum
            #print("nearestPrim", nearestPrim)
            break
    return nearestPrim
 
 
 
t=int(input())
 
for i in range(t):
    inputchrlist = []
    n = int(input())
    inputchrlist=inputchrlist=[i for i in input()]
    outputchrlist=[chr(nearestprim(ord(i))) for i in inputchrlist]
    b=''
    for j in outputchrlist:
        b=b+j
    print(b)
 
Language: Python 3
