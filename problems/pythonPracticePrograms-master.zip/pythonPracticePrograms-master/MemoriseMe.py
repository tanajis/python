from sys import stdin
n=int(stdin.readline())
a=[ i for i in map(int,str(stdin.readline()).split(' '))]
b={}
for i in set(a):
    b[i]=a.count(i)
q=int(stdin.readline())
for i in range(q):
    p=int(stdin.readline())
    if b.__contains__(p):
        print(b[p])
    else:
        print("NOT PRESENT")
