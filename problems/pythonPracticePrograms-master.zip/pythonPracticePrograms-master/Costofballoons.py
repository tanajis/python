t = int(input())
for i in range(t):
    inp = [int(j) for j in str(input()).split(' ')]
    nop = int(input())
    res = []
    for p in range(nop):
        res.append([int(k) for k in str(input()).split(' ')])
    mincost=min(inp[0],inp[1])
    maxcost=max(inp[0],inp[1])
    cnt1=cnt2=0
    for p in res:
        if p[0]==1:
            cnt1=cnt1+1
        if p[1]==1:
            cnt2=cnt2+1
    maxcnt=max(cnt1,cnt2)
    mincnt = min(cnt1, cnt2)
    amt=maxcnt*mincost+mincnt*maxcost
    print(amt)
