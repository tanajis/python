import sys
import smtplib
import psycopg2
import boto3
from boto3 import client as boto3_client
from datetime import datetime
from botocore.exceptions import ClientError
import csv
import json
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
s3BucketName = "bhfl-stg-lms"
sysconfigpath = "sysconfig/config.csv"
emailconfigpath = "sysconfig/emailConfig.csv"
s3 = boto3.resource('s3')


def initconfig():

    obj = s3.Object(s3BucketName, sysconfigpath)
    lines = obj.get()['Body'].read().decode("utf-8").splitlines()

    for row in csv.DictReader(lines):
        if row["SYSTEM"] == 'lms_mart':
            return row["URL"], row['USERNAME'], row['PASSWORD'], row['DB'], row['PORT']


def sendStatusMail(status,err=None):
    if status =='failure':
        text='lambda function bhfl_mob_hsl_wrapper is failed due to Error :' + err
        subject='MOB DLRM job failed'
    else:
        text = 'lambda function bhfl_mob_hsl_wrapper is completed successfully.'
        subject = 'MOB DLRM job completed'
    text=text+"\n\n\n\n"
    message = MIMEMultipart("alternative", None, [MIMEText(text)])
    message['Subject'] = subject
    try:
        obj = s3.Object(s3BucketName, emailconfigpath)
        lines = obj.get()['Body'].read().decode("utf-8").splitlines()
        emailDict = {}
        recipientMaillist = []
        for row in csv.DictReader(lines):
            if row["Password"]:
                emailDict["senderEmail"] = row["Email"]
                emailDict["SenderPassword"] = row["Password"]
            else:
                recipientMaillist.append(row["Email"])
        senderDict = emailDict
        receiverlist = recipientMaillist
        print(senderDict,receiverlist)
        server = smtplib.SMTP('smtp-mail.outlook.com', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(senderDict["senderEmail"], senderDict["SenderPassword"])
        server.sendmail(senderDict["senderEmail"], receiverlist, message.as_string())
        server.close()
        print 'Email sent!'
    except Exception as e:
        logMessage = "failed to execute lambda bhfl_mob_dlrm_wrapper, Error:{} " + str(e)
        print logMessage
        print 'Error on line {}'.format(sys.exc_info()[-1].tb_lineno)

def lambda_handler(event, context):


    rds_host, username, password, db_name, db_port = initconfig()

    job_name = "bhfl_mob_dlrm_wrapper"

    try:
        conn = psycopg2.connect(
            host=rds_host,
            user=username,
            password=password,
            dbname=db_name,
            port=db_port,
            connect_timeout=60,
        )
        cur = conn.cursor()
        print
        'BEGIN: RDS PostgreSQL Functions Invocation'
        cur.callproc('bfl_stage.proc_0mob_dlrm_cdc')
        conn.commit()
        cur.close()
        conn.close()
    except Exception, e:
        print('ERROR: Unexpected error: Could not connect to PgSql instance. %s', str(e))
        a = sendStatusMail('failure', str(e))
        if cur !=None:
            cur.execute('ROLLBACK')
            cur.close()
            conn.close()
        sys.exit()


    try:

        # call glue job
        print "starting glue job : bhfl_stg_mob_dlrm_job"
        #glue_client = boto3.client('glue')
        glue_client = boto3_client('glue')
        glue_client.start_job_run(JobName='bhfl_stg_mob_dlrm_job')
        print "End glue job : bhfl_stg_mob_dlrm_job"
        return
    except Exception, ex:
        print('ERROR: Unexpected error: While running functions %s',str(ex))
        a = sendStatusMail('failure', str(ex))
        print(job_name + "failed")
    #a = sendStatusMail('success')   #commented because we will already get mail from glue after total completion.
    #return

# sys.exit()